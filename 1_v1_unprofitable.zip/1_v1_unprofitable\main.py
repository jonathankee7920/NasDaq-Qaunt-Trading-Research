import os
import pandas as pd
import numpy as np

# Keep large backtest output readable
pd.set_option("display.max_rows", 20)
pd.set_option("display.max_columns", 20)
pd.set_option("display.width", 200)

# Fast mode for large validation backtests
FAST_VALIDATION = True

# ============================================
# DATASET MODE
# ============================================

DATASET_MODE = "V3_VALIDATION"
if DATASET_MODE == "DEVELOPMENT":
    data_file = "nq_1m.csv"

elif DATASET_MODE == "TEST":
    data_file = "nq_1m_test.csv"

elif DATASET_MODE == "HISTORY":
    data_file = "nq_1m_history_1y.csv"

elif DATASET_MODE == "UNSEEN_2Y":
    data_file = "nq_1m_unseen_2y.csv"

elif DATASET_MODE == "V3_VALIDATION":
    data_file = "nq_1m_v3_validation_2y.csv"
else:
    raise ValueError(
        "DATASET_MODE must be DEVELOPMENT, TEST, HISTORY, UNSEEN_2Y or V3_VALIDATION"
    )
   

print()
print("======================================")
print("DATASET MODE:", DATASET_MODE)
print("FILE:", data_file)
print("======================================")

if os.path.exists(data_file):
    print("Loading saved NQ data...")

    df = pd.read_csv(
        data_file,
        index_col="ts_event"
    )

else:
    raise FileNotFoundError(
        f"{data_file} not found."
    )

df.index = (
    pd.to_datetime(df.index, utc=True)
    .tz_convert("Europe/London")
)

print("Candles loaded:", len(df))


df_5m = df.resample("5min").agg({
    "open": "first",
    "high": "max",
    "low": "min",
    "close": "last",
    "volume": "sum",
    "instrument_id": "last"
})

df_5m = df_5m.dropna(subset=["open", "high", "low", "close"])

df_15m = df.resample("15min").agg({
    "open": "first",
    "high": "max",
    "low": "min",
    "close": "last",
    "volume": "sum",
    "instrument_id": "last"
})
df_15m = df_15m.dropna(subset=["open", "high", "low", "close"])
# ============================================
# 15-MINUTE VOLATILITY / ATR
# ============================================

df_15m["contract_roll"] = (
    df_15m["instrument_id"]
    != df_15m["instrument_id"].shift(1)
)

df_15m["contract_segment"] = (
    df_15m["contract_roll"].cumsum()
)

df_15m["previous_close"] = (
    df_15m
    .groupby("contract_segment")["close"]
    .shift(1)
)

df_15m["true_range"] = pd.concat(
    [
        df_15m["high"] - df_15m["low"],
        abs(df_15m["high"] - df_15m["previous_close"]),
        abs(df_15m["low"] - df_15m["previous_close"])
    ],
    axis=1
).max(axis=1)

df_15m["atr_14"] = (
    df_15m
    .groupby("contract_segment")["true_range"]
    .transform(lambda x: x.rolling(14).mean())
) 
print()
print("========== 15M ATR ROLLOVER CHECK ==========")

roll_rows = df_15m[df_15m["contract_roll"]].copy()

previous_close_safe = roll_rows["previous_close"].isna().all()
atr_restart_safe = roll_rows["atr_14"].isna().all()

print("Contract rolls found:", len(roll_rows))
print("Previous close reset:", previous_close_safe)
print("ATR restarted:", atr_restart_safe)

if previous_close_safe and atr_restart_safe:
    print("RESULT: PASS - ATR IS ROLLOVER SAFE")
else:
    print("RESULT: FAIL - CHECK ATR ROLLOVER LOGIC")

print("============================================")

# ============================================
# ATR AVAILABLE AT TRADE TIME
# ============================================

df_15m["atr_14_known"] = (
    df_15m
    .groupby("contract_segment")["atr_14"]
    .shift(1)
)

df_15m["atr_median_500"] = (
    df_15m
    .groupby("contract_segment")["atr_14_known"]
    .transform(
        lambda x: x.rolling(
            500,
            min_periods=100
        ).median()
    )
)

df_15m["atr_ratio"] = (
    df_15m["atr_14_known"]
    / df_15m["atr_median_500"]
)
# df.to_csv("nq_1m.csv")
df_5m.to_csv("nq_5m.csv")
df_15m.to_csv("nq_15m.csv")

print("1 MINUTE DATA")
print(df.head())

print("5 MINUTE DATA")
print(df_5m.head())

print("15 MINUTE DATA")
print(df_15m.head())
print("DATA QUALITY CHECK")

print("Number of 1-minute candles:", len(df))

duplicates = df.index.duplicated().sum()
print("Duplicate timestamps:", duplicates)

missing_values = df[["open", "high", "low", "close", "volume"]].isna().sum()

print("Missing values:")
print(missing_values)

bad_highs = (df["high"] < df[["open", "close"]].max(axis=1)).sum()
bad_lows = (df["low"] > df[["open", "close"]].min(axis=1)).sum()

print("Invalid highs:", bad_highs)
print("Invalid lows:", bad_lows)
time_difference = df.index.to_series().diff()

gaps = time_difference[time_difference > pd.Timedelta(minutes=1)]

print("GAPS LONGER THAN 1 MINUTE")
print(gaps)

df_15m["bearish"] = df_15m["close"] < df_15m["open"]

df_15m["next_candle_bullish"] = df_15m["close"].shift(-1) > df_15m["open"].shift(-1)

df_15m["next_candle_range"] = (
    df_15m["high"].shift(-1) - df_15m["low"].shift(-1)
)

df_15m["demand_zone"] = (
    df_15m["bearish"] &
    df_15m["next_candle_bullish"]
)

print("DEMAND ZONES FOUND")
print(
    df_15m[
        df_15m["demand_zone"]
    ][["open", "high", "low", "close"]]
)
df_15m["body_size"] = abs(df_15m["close"] - df_15m["open"])

df_15m["next_body_size"] = df_15m["body_size"].shift(-1)

df_15m["strong_bullish_move"] = (
    df_15m["next_candle_bullish"] &
    (df_15m["next_body_size"] > df_15m["body_size"])
)

df_15m["demand_zone"] = (
    df_15m["bearish"] &
    df_15m["strong_bullish_move"]
)

if not FAST_VALIDATION:
    print("STRONG DEMAND ZONES FOUND")

    print(
        df_15m[
            df_15m["demand_zone"]
        ][["open", "high", "low", "close", "body_size", "next_body_size"]]
    )
df_15m["average_body"] = (
    df_15m
    .groupby("contract_segment")["body_size"]
    .transform(
        lambda x: x.rolling(10).mean()
    )
)

df_15m["strong_bullish_move"] = (
    df_15m["next_candle_bullish"] &
    (df_15m["next_body_size"] > df_15m["average_body"])
)

df_15m["demand_zone_top"] = df_15m["high"]
df_15m["demand_zone_bottom"] = df_15m["low"]

df_15m["zone_width"] = (
    df_15m["demand_zone_top"] - df_15m["demand_zone_bottom"]
)

df_15m["valid_zone_width"] = df_15m["zone_width"] <= 50

df_15m["demand_zone"] = (
    df_15m["bearish"] &
    df_15m["strong_bullish_move"] &
    df_15m["valid_zone_width"]
)
if not FAST_VALIDATION:
    print("AVERAGE-BASED DEMAND ZONES")

    print(
        df_15m[
            df_15m["demand_zone"]
        ][
            [
                "open",
                "high",
                "low",
                "close",
                "body_size",
                "average_body",
                "next_body_size"
            ]
        ]
    )


if not FAST_VALIDATION:
    print("DEMAND ZONE LEVELS")

    print(
        df_15m[
            df_15m["demand_zone"]
        ][
            [
                "demand_zone_top",
                "demand_zone_bottom",
                "zone_width"
            ]
        ]
    )
# ============================================
# CONTRACT ROLLOVER MARKER
# ============================================

df["contract_roll"] = (
    df["instrument_id"]
    != df["instrument_id"].shift(1)
)

df["contract_segment"] = (
    df["contract_roll"].cumsum()
)

retests = []
retests = []

for zone_time, zone in df_15m[df_15m["demand_zone"]].iterrows():
    zone_top = zone["demand_zone_top"]
    zone_bottom = zone["demand_zone_bottom"]

   
    retest_start_time = zone_time + pd.Timedelta(minutes=30)

    zone_segment = df.loc[
        zone_time,
        "contract_segment"
    ]

    future_data = df[
        (df.index >= retest_start_time) &
        (df["contract_segment"] == zone_segment)
    ]

    for candle_time, candle in future_data.iterrows():
        touched_zone = (
            candle["low"] <= zone_top
            and candle["high"] >= zone_bottom
        )

        if touched_zone:
            retests.append({
                "zone_time": zone_time,
                "zone_top": zone_top,
                "zone_bottom": zone_bottom,
                "retest_time": candle_time,
                "retest_open": candle["open"],
                "retest_high": candle["high"],
                "retest_low": candle["low"],
                "retest_close": candle["close"]
            })

            break

retests_df = pd.DataFrame(retests)

print("FIRST DEMAND ZONE RETESTS")
print(retests_df)

confirmations = []

for _, retest in retests_df.iterrows():

    retest_time = retest["retest_time"]

    retest_segment = df.loc[
        retest_time,
        "contract_segment"
    ]

    before_retest = df[
        (df.index < retest_time) &
        (df.index >= retest_time - pd.Timedelta(minutes=5)) &
        (df["contract_segment"] == retest_segment)
    ]

    after_retest = df[
        (df.index > retest_time) &
        (df.index <= retest_time + pd.Timedelta(minutes=15)) &
        (df["contract_segment"] == retest_segment)
    ]

    if before_retest.empty or after_retest.empty:
        continue

    bos_level = before_retest["high"].max()

    bos_candles = after_retest[
        after_retest["close"] > bos_level
    ]

    if not bos_candles.empty:
        bos_time = bos_candles.index[0]
        bos_candle = bos_candles.iloc[0]

        confirmations.append({
            "zone_time": retest["zone_time"],
            "retest_time": retest_time,
            "bos_level": bos_level,
            "bos_time": bos_time,
            "bos_close": bos_candle["close"]
        })

confirmations_df = pd.DataFrame(confirmations)
print("1 MINUTE BULLISH BOS CONFIRMATIONS")
print(confirmations_df)

df["previous_high_same_contract"] = (
    df.groupby("contract_segment")["high"].shift(1)
)

df["next_high_same_contract"] = (
    df.groupby("contract_segment")["high"].shift(-1)
)

df["swing_high"] = (
    (df["high"] > df["previous_high_same_contract"]) &
    (df["high"] > df["next_high_same_contract"])
)
swing_confirmations = []

for _, retest in retests_df.iterrows():

    retest_time = retest["retest_time"]

    retest_segment = df.loc[
        retest_time,
        "contract_segment"
    ]

    previous_data = df[
        (df.index < retest_time) &
        (df.index >= retest_time - pd.Timedelta(minutes=15)) &
        (df["contract_segment"] == retest_segment)
    ]

    previous_swing_highs = previous_data[
        previous_data["swing_high"]
    ]

    if previous_swing_highs.empty:
        continue

    bos_level = previous_swing_highs.iloc[-1]["high"]

    after_retest = df[
        (df.index > retest_time) &
        (df.index <= retest_time + pd.Timedelta(minutes=15)) &
        (df["contract_segment"] == retest_segment)
    ]

    bos_candles = after_retest[
        after_retest["close"] > bos_level
    ]

    if not bos_candles.empty:

        bos_time = bos_candles.index[0]
        bos_candle = bos_candles.iloc[0]

        swing_confirmations.append({
            "zone_time": retest["zone_time"],
            "retest_time": retest_time,
            "swing_high_level": bos_level,
            "bos_time": bos_time,
            "bos_close": bos_candle["close"]
        })

        swing_confirmations_df = pd.DataFrame(swing_confirmations)

print("SWING HIGH BOS CONFIRMATIONS")
print(swing_confirmations_df)

trades = []

for _, setup in swing_confirmations_df.iterrows():

    retest_time = setup["retest_time"]
    bos_time = setup["bos_time"]

    setup_candles = df[
        (df.index >= retest_time) &
        (df.index <= bos_time)
    ]

    stop_price = setup_candles["low"].min()

    bos_segment = df.loc[
        bos_time,
        "contract_segment"
    ]

    candles_after_bos = df[
        (df.index > bos_time) &
        (df["contract_segment"] == bos_segment)
    ]

    if candles_after_bos.empty:
        continue

    entry_time = candles_after_bos.index[0]
    entry_price = candles_after_bos.iloc[0]["open"]

    risk = entry_price - stop_price

    target_price = entry_price + (risk * 4)

    trades.append({
        "zone_time": setup["zone_time"],
        "retest_time": retest_time,
        "bos_time": bos_time,
        "entry_time": entry_time,
        "entry_price": entry_price,
        "stop_price": stop_price,
        "risk_points": risk,
        "target_price": target_price
    })

    trades_df = pd.DataFrame(trades)

# ============================================
# REMOVE DUPLICATE ENTRY SIGNALS
# Keep the freshest zone when multiple zones
# create a trade at the same entry time.
# ============================================

if not trades_df.empty:

    trades_df = (
        trades_df
        .sort_values(
            ["entry_time", "zone_time"],
            ascending=[True, False]
        )
        .drop_duplicates(
            subset=["entry_time"],
            keep="first"
        )
        
        .sort_values("entry_time")
        .reset_index(drop=True)
    )
segment_data = {
    segment: group
    for segment, group in df.groupby("contract_segment")
}
if not FAST_VALIDATION:
    print("TRADE SETUPS")
    print(trades_df)
trade_results = []

for _, trade in trades_df.iterrows():

    entry_time = trade["entry_time"]
    stop_price = trade["stop_price"]
    target_price = trade["target_price"]

    entry_segment = df.loc[
        entry_time,
        "contract_segment"
    ]

    segment_df = segment_data[entry_segment]

    future_candles = segment_df[
        segment_df.index >= entry_time
    ]

    result = "OPEN"
    exit_time = None
    exit_price = None
    r_result = 0

    for candle_time, candle in future_candles.iterrows():

        stop_hit = candle["low"] <= stop_price
        target_hit = candle["high"] >= target_price

        if stop_hit and target_hit:
            result = "AMBIGUOUS"
            exit_time = candle_time
            break

        elif stop_hit:
            result = "LOSS"
            exit_time = candle_time
            exit_price = stop_price
            r_result = -1
            break

        elif target_hit:
            result = "WIN"
            exit_time = candle_time
            exit_price = target_price
            r_result = 4
            break

    trade_results.append({
        "entry_time": entry_time,
        "entry_price": trade["entry_price"],
        "stop_price": stop_price,
        "target_price": target_price,
        "result": result,
        "exit_time": exit_time,
        "exit_price": exit_price,
        "r_result": r_result
    })

results_df = pd.DataFrame(trade_results)

if not FAST_VALIDATION:
    print("BACKTEST RESULTS")
    print(results_df)


for _, trade in trades_df.iterrows():
    mfe_results = []

for _, trade in trades_df.iterrows():

    entry_time = trade["entry_time"]
    entry_price = trade["entry_price"]
    stop_price = trade["stop_price"]
    risk = trade["risk_points"]

    result_row = results_df[
        results_df["entry_time"] == entry_time
    ].iloc[0]

    exit_time = result_row["exit_time"]

    entry_segment = df.loc[
        entry_time,
        "contract_segment"
    ]

    segment_df = segment_data[entry_segment]

    if pd.isna(exit_time):
        trade_candles = segment_df[
            segment_df.index >= entry_time
        ]
    else:
        trade_candles = segment_df[
            (segment_df.index >= entry_time) &
            (segment_df.index <= exit_time)
        ]

    highest_price = trade_candles["high"].max()
    favourable_points = highest_price - entry_price

    if risk > 0:
        mfe_r = favourable_points / risk
    else:
        mfe_r = None

    mfe_results.append({
        "entry_time": entry_time,
        "entry_price": entry_price,
        "risk_points": risk,
        "highest_price": highest_price,
        "favourable_points": favourable_points,
        "mfe_r": mfe_r,
    })
mfe_df = pd.DataFrame(mfe_results)
print("DEBUG trades_df rows:", len(trades_df))
print("DEBUG results_df rows:", len(results_df))
print("DEBUG mfe_results rows:", len(mfe_results))
print("DEBUG mfe_df columns:", mfe_df.columns.tolist())
if not FAST_VALIDATION:
    print("MAXIMUM FAVOURABLE EXCURSION")
    print(mfe_df)
# -----------------------------
# BACKTEST PERFORMANCE SUMMARY
# -----------------------------

completed_trades = results_df[
    results_df["result"].isin(["WIN", "LOSS"])
]

total_trades = len(completed_trades)

wins = (completed_trades["result"] == "WIN").sum()
losses = (completed_trades["result"] == "LOSS").sum()

win_rate = (wins / total_trades) * 100 if total_trades > 0 else 0

total_r = completed_trades["r_result"].sum()
average_r = completed_trades["r_result"].mean()

gross_wins = completed_trades.loc[
    completed_trades["r_result"] > 0,
    "r_result"
].sum()

gross_losses = abs(
    completed_trades.loc[
        completed_trades["r_result"] < 0,
        "r_result"
    ].sum()
)

profit_factor = (
    gross_wins / gross_losses
    if gross_losses > 0
    else float("inf")
)

completed_trades = completed_trades.copy()

completed_trades["cumulative_r"] = (
    completed_trades["r_result"].cumsum()
)

completed_trades["equity_peak"] = (
    completed_trades["cumulative_r"].cummax()
)

completed_trades["drawdown_r"] = (
    completed_trades["cumulative_r"]
    - completed_trades["equity_peak"]
)

max_drawdown = completed_trades["drawdown_r"].min()
if "mfe_r" in mfe_df.columns:
    mfe_df = mfe_df[
        np.isfinite(mfe_df["mfe_r"])
    ].copy()
else:
    print("WARNING: No MFE results were created.")
average_mfe = mfe_df["mfe_r"].dropna().mean()
median_mfe = mfe_df["mfe_r"].dropna().median()
print()
print("========== STRATEGY SUMMARY ==========")
print("Total trades:", total_trades)
print("Wins:", wins)
print("Losses:", losses)
print("Win rate:", round(win_rate, 2), "%")
print("Total R:", round(total_r, 2))
print("Average R per trade:", round(average_r, 3))
print("Profit factor:", round(profit_factor, 2))
print("Maximum drawdown:", round(max_drawdown, 2), "R")
print("Average MFE:", round(average_mfe, 2), "R")
print("Median MFE:", round(median_mfe, 2), "R")
print("======================================")
segment_data = {
    segment: group
    for segment, group in df.groupby("contract_segment")
}
# --------------------------------
# MULTI RISK-REWARD COMPARISON
# --------------------------------

rr_values = [1, 1.5, 2, 2.5, 3, 3.5, 4]

rr_results = []

for rr in rr_values:

    wins = 0
    losses = 0
    ambiguous = 0
    total_r = 0

    for _, trade in trades_df.iterrows():

        entry_time = trade["entry_time"]
        entry_price = trade["entry_price"]
        stop_price = trade["stop_price"]
        risk = trade["risk_points"]

        target_price = entry_price + (risk * rr)

        entry_segment = df.loc[
            entry_time,
            "contract_segment"
        ]

        segment_df = segment_data[entry_segment]

        future_candles = segment_df[
            segment_df.index >= entry_time
        ]

        trade_result = None
    for candle_time, candle in future_candles.iterrows():

            stop_hit = candle["low"] <= stop_price
            target_hit = candle["high"] >= target_price

            if stop_hit and target_hit:
                trade_result = "AMBIGUOUS"
                ambiguous += 1
                break

            elif stop_hit:
                trade_result = "LOSS"
                losses += 1
                total_r -= 1
                break

            elif target_hit:
                trade_result = "WIN"
                wins += 1
                total_r += rr
                break

    completed = wins + losses

    if completed > 0:
        win_rate = (wins / completed) * 100
        average_r = total_r / completed
    else:
        win_rate = 0
        average_r = 0

    gross_wins = wins * rr
    gross_losses = losses

    if gross_losses > 0:
        profit_factor = gross_wins / gross_losses
    else:
        profit_factor = float("inf")

    rr_results.append({
        "RR": rr,
        "Trades": completed,
        "Wins": wins,
        "Losses": losses,
        "Ambiguous": ambiguous,
        "Win_Rate": round(win_rate, 2),
        "Total_R": round(total_r, 2),
        "Average_R": round(average_r, 3),
        "Profit_Factor": round(profit_factor, 2)
    })

rr_df = pd.DataFrame(rr_results)
print()
print("========== RISK REWARD COMPARISON ==========")
print(rr_df.to_string(index=False))
print("============================================")
# --------------------------------
# STOP SIZE ANALYSIS
# --------------------------------

analysis_df = trades_df.copy()

analysis_df["result"] = results_df["result"]
analysis_df["r_result"] = results_df["r_result"]

analysis_df["stop_size_group"] = pd.cut(
    analysis_df["risk_points"],
    bins=[0, 5, 10, 20, 40, 80, float("inf")],
    labels=[
        "0-5",
        "5-10",
        "10-20",
        "20-40",
        "40-80",
        "80+"
    ]
)

stop_size_summary = (
    analysis_df[
        analysis_df["result"].isin(["WIN", "LOSS"])
    ]
    .groupby("stop_size_group", observed=False)
    .agg(
        trades=("result", "count"),
        wins=("result", lambda x: (x == "WIN").sum()),
        losses=("result", lambda x: (x == "LOSS").sum()),
        total_r=("r_result", "sum"),
        average_r=("r_result", "mean"),
        average_stop=("risk_points", "mean")
    )
)

stop_size_summary["win_rate"] = (
    stop_size_summary["wins"]
    / stop_size_summary["trades"]
    * 100
)
# --------------------------------
# TIME OF DAY ANALYSIS
# --------------------------------

time_analysis_df = trades_df.copy()

time_analysis_df["result"] = results_df["result"]
time_analysis_df["r_result"] = results_df["r_result"]

# Get entry hour from the timestamp
time_analysis_df["entry_hour"] = (
    time_analysis_df["entry_time"].dt.hour
)

# Group trades by entry hour
hour_summary = (
    time_analysis_df[
        time_analysis_df["result"].isin(["WIN", "LOSS"])
    ]
    .groupby("entry_hour")
    .agg(
        trades=("result", "count"),
        wins=("result", lambda x: (x == "WIN").sum()),
        losses=("result", lambda x: (x == "LOSS").sum()),
        total_r=("r_result", "sum"),
        average_r=("r_result", "mean")
    )
)

hour_summary["win_rate"] = (
    hour_summary["wins"]
    / hour_summary["trades"]
    * 100
)
# --------------------------------
# BOS SPEED ANALYSIS
# --------------------------------

bos_analysis_df = trades_df.copy()

bos_analysis_df["result"] = results_df["result"]
bos_analysis_df["r_result"] = results_df["r_result"]

# Calculate minutes between retest and BOS
bos_analysis_df["bos_delay_minutes"] = (
    (
        bos_analysis_df["bos_time"]
        - bos_analysis_df["retest_time"]
    )
    .dt.total_seconds()
    / 60
)

# Put BOS speed into groups
bos_analysis_df["bos_speed_group"] = pd.cut(
    bos_analysis_df["bos_delay_minutes"],
    bins=[0, 1, 3, 5, 10, 15, float("inf")],
    labels=[
        "0-1 min",
        "1-3 min",
        "3-5 min",
        "5-10 min",
        "10-15 min",
        "15+ min"
    ],
    include_lowest=True
)

bos_speed_summary = (
    bos_analysis_df[
        bos_analysis_df["result"].isin(["WIN", "LOSS"])
    ]
    .groupby("bos_speed_group", observed=False)
    .agg(
        trades=("result", "count"),
        wins=("result", lambda x: (x == "WIN").sum()),
        losses=("result", lambda x: (x == "LOSS").sum()),
        total_r=("r_result", "sum"),
        average_r=("r_result", "mean"),
        average_bos_delay=("bos_delay_minutes", "mean")
    )
)

bos_speed_summary["win_rate"] = (
    bos_speed_summary["wins"]
    / bos_speed_summary["trades"]
    * 100
)
# --------------------------------
# ZONE WIDTH ANALYSIS
# --------------------------------

zone_analysis_df = trades_df.copy()

zone_analysis_df["result"] = results_df["result"]
zone_analysis_df["r_result"] = results_df["r_result"]

# Match each trade back to its original 15-minute zone
zone_width_map = df_15m["zone_width"]

zone_analysis_df["zone_width"] = (
    zone_analysis_df["zone_time"].map(zone_width_map)
)

# Put zone widths into groups
zone_analysis_df["zone_width_group"] = pd.cut(
    zone_analysis_df["zone_width"],
    bins=[0, 10, 20, 30, 40, 50, float("inf")],
    labels=[
        "0-10",
        "10-20",
        "20-30",
        "30-40",
        "40-50",
        "50+"
    ],
    include_lowest=True
)

zone_width_summary = (
    zone_analysis_df[
        zone_analysis_df["result"].isin(["WIN", "LOSS"])
    ]
    .groupby("zone_width_group", observed=False)
    .agg(
        trades=("result", "count"),
        wins=("result", lambda x: (x == "WIN").sum()),
        losses=("result", lambda x: (x == "LOSS").sum()),
        total_r=("r_result", "sum"),
        average_r=("r_result", "mean"),
        average_zone_width=("zone_width", "mean")
    )
)

zone_width_summary["win_rate"] = (
    zone_width_summary["wins"]
    / zone_width_summary["trades"]
    * 100
)
# --------------------------------
# DISPLACEMENT STRENGTH ANALYSIS
# --------------------------------

displacement_df = trades_df.copy()

displacement_df["result"] = results_df["result"]
displacement_df["r_result"] = results_df["r_result"]

# Get displacement information from the original zone
displacement_df["next_body_size"] = (
    displacement_df["zone_time"].map(
        df_15m["next_body_size"]
    )
)

displacement_df["average_body"] = (
    displacement_df["zone_time"].map(
        df_15m["average_body"]
    )
)

# Calculate displacement strength
displacement_df["displacement_strength"] = (
    displacement_df["next_body_size"]
    / displacement_df["average_body"]
)

# Group displacement strength
displacement_df["displacement_group"] = pd.cut(
    displacement_df["displacement_strength"],
    bins=[0, 1, 1.5, 2, 3, 4, float("inf")],
    labels=[
        "0-1x",
        "1-1.5x",
        "1.5-2x",
        "2-3x",
        "3-4x",
        "4x+"
    ],
    include_lowest=True
)

displacement_summary = (
    displacement_df[
        displacement_df["result"].isin(["WIN", "LOSS"])
    ]
    .groupby("displacement_group", observed=False)
    .agg(
        trades=("result", "count"),
        wins=("result", lambda x: (x == "WIN").sum()),
        losses=("result", lambda x: (x == "LOSS").sum()),
        total_r=("r_result", "sum"),
        average_r=("r_result", "mean"),
        average_strength=("displacement_strength", "mean")
    )
)

displacement_summary["win_rate"] = (
    displacement_summary["wins"]
    / displacement_summary["trades"]
    * 100
)
# --------------------------------
# RETEST DEPTH ANALYSIS
# --------------------------------

retest_depth_df = trades_df.copy()

retest_depth_df["result"] = results_df["result"]
retest_depth_df["r_result"] = results_df["r_result"]

# Get original zone levels
retest_depth_df["zone_top"] = (
    retest_depth_df["zone_time"].map(
        df_15m["demand_zone_top"]
    )
)

retest_depth_df["zone_bottom"] = (
    retest_depth_df["zone_time"].map(
        df_15m["demand_zone_bottom"]
    )
)

retest_depth_df["zone_width"] = (
    retest_depth_df["zone_top"]
    - retest_depth_df["zone_bottom"]
)

depth_values = []

for _, trade in retest_depth_df.iterrows():

    retest_time = trade["retest_time"]
    bos_time = trade["bos_time"]

    # All 1-minute candles from retest through BOS
    retest_to_bos = df[
        (df.index >= retest_time) &
        (df.index <= bos_time)
    ]

    if retest_to_bos.empty:
        depth_values.append(float("nan"))
        continue

    lowest_price = retest_to_bos["low"].min()

    zone_top = trade["zone_top"]
    zone_width = trade["zone_width"]

    if zone_width <= 0:
        depth_values.append(float("nan"))
        continue

    depth_percent = (
        (zone_top - lowest_price)
        / zone_width
        * 100
    )

    depth_values.append(depth_percent)

retest_depth_df["retest_depth_percent"] = depth_values

# Group depth
retest_depth_df["depth_group"] = pd.cut(
    retest_depth_df["retest_depth_percent"],
    bins=[
        float("-inf"),
        25,
        50,
        75,
        100,
        float("inf")
    ],
    labels=[
        "0-25%",
        "25-50%",
        "50-75%",
        "75-100%",
        "100%+"
    ]
)

retest_depth_summary = (
    retest_depth_df[
        retest_depth_df["result"].isin(["WIN", "LOSS"])
    ]
    .groupby("depth_group", observed=False)
    .agg(
        trades=("result", "count"),
        wins=("result", lambda x: (x == "WIN").sum()),
        losses=("result", lambda x: (x == "LOSS").sum()),
        total_r=("r_result", "sum"),
        average_r=("r_result", "mean"),
        average_depth=("retest_depth_percent", "mean")
    )
)

retest_depth_summary["win_rate"] = (
    retest_depth_summary["wins"]
    / retest_depth_summary["trades"]
    * 100
)
# --------------------------------
# ZONE FRESHNESS ANALYSIS
# --------------------------------

freshness_df = trades_df.copy()

freshness_df["result"] = results_df["result"]
freshness_df["r_result"] = results_df["r_result"]

# Calculate minutes between zone creation and retest
freshness_df["minutes_to_retest"] = (
    (
        freshness_df["retest_time"]
        - freshness_df["zone_time"]
    )
    .dt.total_seconds()
    / 60
)

# Group zones by how long they took to retest
freshness_df["freshness_group"] = pd.cut(
    freshness_df["minutes_to_retest"],
    bins=[
        0,
        30,
        60,
        120,
        240,
        480,
        float("inf")
    ],
    labels=[
        "0-30 min",
        "30-60 min",
        "1-2 hours",
        "2-4 hours",
        "4-8 hours",
        "8+ hours"
    ],
    include_lowest=True
)

freshness_summary = (
    freshness_df[
        freshness_df["result"].isin(["WIN", "LOSS"])
    ]
    .groupby("freshness_group", observed=False)
    .agg(
        trades=("result", "count"),
        wins=("result", lambda x: (x == "WIN").sum()),
        losses=("result", lambda x: (x == "LOSS").sum()),
        total_r=("r_result", "sum"),
        average_r=("r_result", "mean"),
        average_minutes=("minutes_to_retest", "mean")
    )
)

freshness_summary["win_rate"] = (
    freshness_summary["wins"]
    / freshness_summary["trades"]
    * 100
)
# --------------------------------
# COMBINED FEATURE ANALYSIS
# --------------------------------

combined_df = trades_df.copy()

combined_df["result"] = results_df["result"]
combined_df["r_result"] = results_df["r_result"]

# BOS delay
combined_df["bos_delay"] = (
    (
        combined_df["bos_time"]
        - combined_df["retest_time"]
    )
    .dt.total_seconds()
    / 60
)

# Retest depth from our previous analysis
combined_df["retest_depth"] = (
    retest_depth_df["retest_depth_percent"]
)

# Displacement strength
combined_df["displacement_strength"] = (
    combined_df["zone_time"].map(
        df_15m["next_body_size"]
    )
    /
    combined_df["zone_time"].map(
        df_15m["average_body"]
    )
)

# Create individual feature flags
combined_df["good_stop"] = (
    (combined_df["risk_points"] >= 10)
    &
    (combined_df["risk_points"] <= 20)
)

combined_df["good_bos"] = (
    combined_df["bos_delay"] <= 5
)

combined_df["good_depth"] = (
    combined_df["retest_depth"] <= 25
)

combined_df["good_displacement"] = (
    (combined_df["displacement_strength"] >= 1)
    &
    (combined_df["displacement_strength"] <= 1.5)
)

# Count how many promising features each trade has
combined_df["quality_score"] = (
    combined_df["good_stop"].astype(int)
    + combined_df["good_bos"].astype(int)
    + combined_df["good_depth"].astype(int)
    + combined_df["good_displacement"].astype(int)
)

quality_summary = (
    combined_df[
        combined_df["result"].isin(["WIN", "LOSS"])
    ]
    .groupby("quality_score")
    .agg(
        trades=("result", "count"),
        wins=("result", lambda x: (x == "WIN").sum()),
        losses=("result", lambda x: (x == "LOSS").sum()),
        total_r=("r_result", "sum"),
        average_r=("r_result", "mean")
    )
)

quality_summary["win_rate"] = (
    quality_summary["wins"]
    / quality_summary["trades"]
    * 100
)
# --------------------------------
# FEATURE COMBINATION ANALYSIS
# --------------------------------

combo_df = combined_df.copy()

# Create an easy-to-read name for each combination
def get_combination_name(row):

    features = []

    if row["good_stop"]:
        features.append("STOP")

    if row["good_bos"]:
        features.append("BOS")

    if row["good_depth"]:
        features.append("DEPTH")

    if row["good_displacement"]:
        features.append("DISP")

    if len(features) == 0:
        return "NONE"

    return " + ".join(features)


combo_df["feature_combination"] = combo_df.apply(
    get_combination_name,
    axis=1
)

combo_summary = (
    combo_df[
        combo_df["result"].isin(["WIN", "LOSS"])
    ]
    .groupby("feature_combination")
    .agg(
        trades=("result", "count"),
        wins=("result", lambda x: (x == "WIN").sum()),
        losses=("result", lambda x: (x == "LOSS").sum()),
        total_r=("r_result", "sum"),
        average_r=("r_result", "mean")
    )
)

combo_summary["win_rate"] = (
    combo_summary["wins"]
    / combo_summary["trades"]
    * 100
)

# Sort best Total R first
combo_summary = combo_summary.sort_values(
    "total_r",
    ascending=False
)
# ============================================
# FREEZE STRATEGY VERSION 1
# ============================================

# V1 RULE:
# A trade must satisfy at least 3 of the
# 4 quality conditions discovered during
# development testing.

v1_df = combined_df[
    combined_df["quality_score"] >= 3
].copy()

# Only completed trades
v1_completed = v1_df[
    v1_df["result"].isin(["WIN", "LOSS"])
].copy()

v1_trades = len(v1_completed)

v1_wins = (
    v1_completed["result"] == "WIN"
).sum()

v1_losses = (
    v1_completed["result"] == "LOSS"
).sum()

v1_win_rate = (
    (v1_wins / v1_trades) * 100
    if v1_trades > 0
    else 0
)

v1_total_r = v1_completed["r_result"].sum()

v1_average_r = (
    v1_completed["r_result"].mean()
    if v1_trades > 0
    else 0
)

v1_gross_wins = v1_completed.loc[
    v1_completed["r_result"] > 0,
    "r_result"
].sum()

v1_gross_losses = abs(
    v1_completed.loc[
        v1_completed["r_result"] < 0,
        "r_result"
    ].sum()
)

v1_profit_factor = (
    v1_gross_wins / v1_gross_losses
    if v1_gross_losses > 0
    else float("inf")
)

# Cumulative R
v1_completed["cumulative_r"] = (
    v1_completed["r_result"].cumsum()
)

v1_completed["equity_peak"] = (
    v1_completed["cumulative_r"].cummax()
)

v1_completed["drawdown_r"] = (
    v1_completed["cumulative_r"]
    - v1_completed["equity_peak"]
)

v1_max_drawdown = (
    v1_completed["drawdown_r"].min()
    if v1_trades > 0
    else 0
)

print()
print("========== FROZEN STRATEGY V1 ==========")

print()
print("RULES:")
print("15m demand zone")
print("Strong bullish displacement")
print("First retest")
print("1m bullish BOS")
print("Entry on next 1m candle")
print("Target = 4R")
print()
print("QUALITY FILTER: minimum 3 of 4")
print("1. Stop = 10-20 points")
print("2. BOS delay <= 5 minutes")
print("3. Retest depth <= 25%")
print("4. Displacement = 1.0-1.5x average")

print()
print("DEVELOPMENT RESULTS:")
print("Trades:", v1_trades)
print("Wins:", v1_wins)
print("Losses:", v1_losses)
print("Win rate:", round(v1_win_rate, 2), "%")
print("Total R:", round(v1_total_r, 2))
print("Average R:", round(v1_average_r, 3))
print("Profit factor:", round(v1_profit_factor, 2))
print(
    "Maximum drawdown:",
    round(v1_max_drawdown, 2),
    "R"
)

print("========================================")

# Save V1 trades without overwriting another dataset
if DATASET_MODE == "DEVELOPMENT":
    strategy_output_file = "strategy_v1_development_trades.csv"
else:
    strategy_output_file = "strategy_v1_test_trades.csv"

v1_completed.to_csv(
    strategy_output_file,
    index=False
)

print()
print("Saved", strategy_output_file)
print()
print("========== FEATURE COMBINATION ANALYSIS ==========")
print(combo_summary.round(2))
print("==================================================")
print()
print("========== COMBINED FEATURE ANALYSIS ==========")
print(quality_summary.round(2))
print("===============================================")
print()
print("========== ZONE FRESHNESS ANALYSIS ==========")
print(freshness_summary.round(2))
print("=============================================")
print()
print("========== RETEST DEPTH ANALYSIS ==========")
print(retest_depth_summary.round(2))
print("===========================================")
print()
print("========== DISPLACEMENT STRENGTH ANALYSIS ==========")
print(displacement_summary.round(2))
print("====================================================")
print()
print("========== ZONE WIDTH ANALYSIS ==========")
print(zone_width_summary.round(2))
print("=========================================")
print()
print("========== BOS SPEED ANALYSIS ==========")
print(bos_speed_summary.round(2))
print("========================================")
print()
print("========== TIME OF DAY ANALYSIS ==========")
print(hour_summary.round(2))
print("==========================================")
print()
print("========== STOP SIZE ANALYSIS ==========")
print(stop_size_summary.round(2))
print("========================================")
df_15m["zone_width"] = (
    df_15m["demand_zone_top"] - df_15m["demand_zone_bottom"]
)
df_15m["valid_zone_width"] = df_15m["zone_width"] <= 50
# ============================================
# BACKTEST AUDIT
# ============================================

print()
print("========== BACKTEST AUDIT ==========")

# 1. Count all setups
total_setups = len(trades_df)

# 2. Count result types
result_counts = results_df["result"].value_counts(dropna=False)

wins_count = (results_df["result"] == "WIN").sum()
losses_count = (results_df["result"] == "LOSS").sum()
ambiguous_count = (results_df["result"] == "AMBIGUOUS").sum()
open_count = (results_df["result"] == "OPEN").sum()

print("Trade setups:", total_setups)
print("Wins:", wins_count)
print("Losses:", losses_count)
print("Ambiguous:", ambiguous_count)
print("Open:", open_count)
print(
    "Accounted for:",
    wins_count + losses_count + ambiguous_count + open_count
)

# 3. Duplicate entries
duplicate_entries = (
    trades_df["entry_time"].duplicated().sum()
)

print("Duplicate entry times:", duplicate_entries)

# 4. Entry must happen after BOS
bad_entry_timing = (
    trades_df["entry_time"]
    <= trades_df["bos_time"]
).sum()

print(
    "Entries at/before BOS:",
    bad_entry_timing
)

# 5. BOS must happen after retest
bad_bos_timing = (
    trades_df["bos_time"]
    <= trades_df["retest_time"]
).sum()

print(
    "BOS at/before retest:",
    bad_bos_timing
)

# 6. Retest must happen after zone creation
bad_retest_timing = (
    trades_df["retest_time"]
    <= trades_df["zone_time"]
).sum()

print(
    "Retests at/before zone creation:",
    bad_retest_timing
)

# 7. Very old zones
zone_age_minutes = (
    (
        trades_df["retest_time"]
        - trades_df["zone_time"]
    )
    .dt.total_seconds()
    / 60
)

print(
    "Zones older than 8 hours:",
    (zone_age_minutes > 480).sum()
)

print(
    "Zones older than 24 hours:",
    (zone_age_minutes > 1440).sum()
)

print(
    "Oldest zone age (hours):",
    round(zone_age_minutes.max() / 60, 2)
)

# 8. Check degraded Databento date
degraded_date = pd.Timestamp(
    "2026-07-30",
    tz="Europe/London"
).date()

degraded_trades = trades_df[
    trades_df["entry_time"].dt.date == degraded_date
]

print(
    "Trades on degraded date 2026-07-30:",
    len(degraded_trades)
)

print("====================================")
# ============================================
# DUPLICATE ENTRY INSPECTION
# ============================================

duplicate_mask = trades_df["entry_time"].duplicated(
    keep=False
)

duplicate_trades = trades_df[
    duplicate_mask
].copy()

print()
print("========== DUPLICATE ENTRY INSPECTION ==========")

if duplicate_trades.empty:

    print("No duplicate entry times found.")

else:

    duplicate_columns = [
        "zone_time",
        "retest_time",
        "bos_time",
        "entry_time",
        "entry_price",
        "stop_price",
        "risk_points",
        "target_price"
    ]

    print(
        duplicate_trades[
            duplicate_columns
        ].sort_values("entry_time").to_string(
            index=False
        )
    )

print("================================================")
# ============================================
# STALE ZONE INSPECTION
# ============================================

stale_trades = trades_df.copy()

stale_trades["zone_age_hours"] = (
    (
        stale_trades["retest_time"]
        - stale_trades["zone_time"]
    )
    .dt.total_seconds()
    / 3600
)

stale_trades = stale_trades[
    stale_trades["zone_age_hours"] > 8
]

print()
print("========== STALE ZONE INSPECTION ==========")

if stale_trades.empty:

    print("No zones older than 8 hours.")

else:

    stale_columns = [
        "zone_time",
        "retest_time",
        "bos_time",
        "entry_time",
        "zone_age_hours",
        "entry_price",
        "stop_price",
        "target_price"
    ]

    print(
        stale_trades[
            stale_columns
        ]
        .sort_values("entry_time")
        .to_string(index=False)
    )

print("===========================================")
# ============================================
# V1 STALE ZONE CHECK
# ============================================

v1_stale_check = v1_completed.copy()

v1_stale_check["zone_age_hours"] = (
    (
        v1_stale_check["retest_time"]
        - v1_stale_check["zone_time"]
    )
    .dt.total_seconds()
    / 3600
)

print()
print("========== V1 STALE ZONE CHECK ==========")

print(
    v1_stale_check[
        [
            "zone_time",
            "retest_time",
            "entry_time",
            "zone_age_hours",
            "r_result"
        ]
    ]
    .sort_values("zone_age_hours", ascending=False)
    .to_string(index=False)
)

print("=========================================")
# ============================================
# JUNE 16 ROLLOVER INSPECTION
# ============================================

roll_start = pd.Timestamp(
    "2026-06-15 00:00",
    tz="Europe/London"
)

roll_end = pd.Timestamp(
    "2026-06-17 23:59",
    tz="Europe/London"
)

roll_data = df[
    (df.index >= roll_start) &
    (df.index <= roll_end)
].copy()

roll_data["previous_close"] = roll_data["close"].shift(1)

roll_data["gap_points"] = (
    roll_data["open"]
    - roll_data["previous_close"]
).abs()

largest_gaps = (
    roll_data[
        [
            "open",
            "high",
            "low",
            "close",
            "previous_close",
            "gap_points"
        ]
    ]
    .sort_values(
        "gap_points",
        ascending=False
    )
    .head(10)
)

print()
print("========== JUNE 16 ROLLOVER CHECK ==========")
print(largest_gaps.to_string())
print("============================================")
print()
print("========== DATA COLUMNS ==========")
print(df.columns.tolist())
print("==================================")
print()
print("========== INSTRUMENT ID CHANGES ==========")

instrument_changes = df[
    df["instrument_id"] != df["instrument_id"].shift(1)
][
    [
        "instrument_id",
        "symbol",
        "open",
        "close"
    ]
]

print(instrument_changes.to_string())

print("===========================================")
# ============================================
# V1 MONTHLY PERFORMANCE
# ============================================

v1_monthly = v1_completed.copy()

v1_monthly["month"] = (
    v1_monthly["entry_time"]
    .dt.to_period("M")
)

monthly_summary = (
    v1_monthly
    .groupby("month")
    .agg(
        trades=("r_result", "count"),
        wins=("result", lambda x: (x == "WIN").sum()),
        losses=("result", lambda x: (x == "LOSS").sum()),
        total_r=("r_result", "sum"),
        average_r=("r_result", "mean")
    )
)

monthly_summary["win_rate"] = (
    monthly_summary["wins"]
    / monthly_summary["trades"]
    * 100
)
# ============================================
# MONTHLY MARKET VOLATILITY
# ============================================

monthly_market = df.copy()

monthly_market["month"] = (
    monthly_market.index.to_period("M")
)

monthly_market["range_points"] = (
    monthly_market["high"]
    - monthly_market["low"]
)

monthly_volatility = (
    monthly_market
    .groupby("month")
    .agg(
        average_1m_range=("range_points", "mean"),
        median_1m_range=("range_points", "median")
    )
)

monthly_regime_summary = monthly_summary.join(
    monthly_volatility,
    how="left"
)

print()
print("========== V1 MONTHLY + VOLATILITY ==========")
print(
    monthly_regime_summary
    .round(2)
    .to_string()
)
# ============================================
# MONTHLY MARKET DIRECTION
# ============================================

monthly_direction = (
    df.resample("ME")
    .agg(
        month_open=("open", "first"),
        month_high=("high", "max"),
        month_low=("low", "min"),
        month_close=("close", "last")
    )
)

monthly_direction["monthly_change_pct"] = (
    (
        monthly_direction["month_close"]
        - monthly_direction["month_open"]
    )
    / monthly_direction["month_open"]
    * 100
)

monthly_direction["month"] = (
    monthly_direction.index.to_period("M")
)

monthly_direction = (
    monthly_direction
    .set_index("month")
)

monthly_regime_summary = (
    monthly_regime_summary
    .join(
        monthly_direction[
            ["monthly_change_pct"]
        ],
        how="left"
    )
)

print()
print("========== V1 MONTHLY + REGIME ==========")
print(
    monthly_regime_summary
    .round(2)
    .to_string()
)
# ============================================
# V1 LOCAL TREND ANALYSIS
# ============================================

df["ema_60"] = df["close"].ewm(span=60, adjust=False).mean()

v1_local = v1_completed.copy()

v1_local["ema_60"] = v1_local["entry_time"].map(
    df["ema_60"]
)

v1_local["entry_vs_ema"] = (
    v1_local["entry_price"] - v1_local["ema_60"]
)

v1_local["trend_regime"] = "BELOW_EMA"

v1_local.loc[
    v1_local["entry_price"] > v1_local["ema_60"],
    "trend_regime"
] = "ABOVE_EMA"

local_trend_summary = (
    v1_local
    .groupby("trend_regime")
    .agg(
        trades=("r_result", "count"),
        wins=("result", lambda x: (x == "WIN").sum()),
        losses=("result", lambda x: (x == "LOSS").sum()),
        total_r=("r_result", "sum"),
        average_r=("r_result", "mean")
    )
)

local_trend_summary["win_rate"] = (
    local_trend_summary["wins"]
    / local_trend_summary["trades"]
    * 100
)
# ============================================
# V1 TIME OF DAY ANALYSIS
# ============================================

v1_time = v1_completed.copy()

v1_time["entry_hour_london"] = (
    v1_time["entry_time"].dt.hour
)

v1_time_summary = (
    v1_time
    .groupby("entry_hour_london")
    .agg(
        trades=("r_result", "count"),
        wins=("result", lambda x: (x == "WIN").sum()),
        losses=("result", lambda x: (x == "LOSS").sum()),
        total_r=("r_result", "sum"),
        average_r=("r_result", "mean")
    )
)

v1_time_summary["win_rate"] = (
    v1_time_summary["wins"]
    / v1_time_summary["trades"]
    * 100
)
# ============================================
# V1 NEW YORK SESSION ANALYSIS
# ============================================

v1_session = v1_completed.copy()

# Convert London/UTC-aware entry times to New York time
v1_session["entry_time_ny"] = (
    v1_session["entry_time"]
    .dt.tz_convert("America/New_York")
)

v1_session["ny_hour"] = (
    v1_session["entry_time_ny"].dt.hour
)

v1_session["ny_minute"] = (
    v1_session["entry_time_ny"].dt.minute
)

# Convert time to minutes after midnight
v1_session["ny_minutes"] = (
    v1_session["ny_hour"] * 60
    + v1_session["ny_minute"]
)

# Default session
v1_session["session"] = "OVERNIGHT"

# 04:00 - 09:29 ET
v1_session.loc[
    (v1_session["ny_minutes"] >= 240) &
    (v1_session["ny_minutes"] < 570),
    "session"
] = "PREMARKET"

# 09:30 - 12:00 ET
v1_session.loc[
    (v1_session["ny_minutes"] >= 570) &
    (v1_session["ny_minutes"] < 720),
    "session"
] = "NY_MORNING"

# 12:00 - 16:00 ET
v1_session.loc[
    (v1_session["ny_minutes"] >= 720) &
    (v1_session["ny_minutes"] < 960),
    "session"
] = "NY_AFTERNOON"

# 16:00 - 18:00 ET
v1_session.loc[
    (v1_session["ny_minutes"] >= 960) &
    (v1_session["ny_minutes"] < 1080),
    "session"
] = "AFTER_HOURS"

session_summary = (
    v1_session
    .groupby("session")
    .agg(
        trades=("r_result", "count"),
        wins=("result", lambda x: (x == "WIN").sum()),
        losses=("result", lambda x: (x == "LOSS").sum()),
        total_r=("r_result", "sum"),
        average_r=("r_result", "mean")
    )
)

session_summary["win_rate"] = (
    session_summary["wins"]
    / session_summary["trades"]
    * 100
)
# ============================================
# V1 NEW YORK 30-MINUTE ANALYSIS
# ============================================

v1_30m = v1_session.copy()

v1_30m["time_bucket"] = (
    v1_30m["entry_time_ny"].dt.floor("30min").dt.strftime("%H:%M")
)

time_30m_summary = (
    v1_30m
    .groupby("time_bucket")
    .agg(
        trades=("r_result", "count"),
        wins=("result", lambda x: (x == "WIN").sum()),
        losses=("result", lambda x: (x == "LOSS").sum()),
        total_r=("r_result", "sum"),
        average_r=("r_result", "mean")
    )
)

time_30m_summary["win_rate"] = (
    time_30m_summary["wins"]
    / time_30m_summary["trades"]
    * 100
)
# ============================================
# V1 WINNER VS LOSER FEATURE ANALYSIS
# ============================================

feature_columns = [
    "risk_points",
    "bos_delay",
    "retest_depth",
    "displacement_strength"
]

winner_features = (
    v1_completed[
        v1_completed["result"] == "WIN"
    ][feature_columns]
    .agg(["count", "mean", "median", "min", "max"])
    .T
)

loser_features = (
    v1_completed[
        v1_completed["result"] == "LOSS"
    ][feature_columns]
    .agg(["count", "mean", "median", "min", "max"])
    .T
)

feature_comparison = winner_features.join(
    loser_features,
    lsuffix="_WIN",
    rsuffix="_LOSS"
)
# ============================================
# V1 RETEST DEPTH BANDS
# ============================================

v1_depth = v1_completed.copy()

v1_depth["depth_band"] = pd.cut(
    v1_depth["retest_depth"],
    bins=[
        0,
        10,
        20,
        30,
        40,
        50,
        75,
        100
    ],
    include_lowest=True
)

depth_summary = (
    v1_depth
    .groupby(
        "depth_band",
        observed=True
    )
    .agg(
        trades=("r_result", "count"),
        wins=("result", lambda x: (x == "WIN").sum()),
        losses=("result", lambda x: (x == "LOSS").sum()),
        total_r=("r_result", "sum"),
        average_r=("r_result", "mean")
    )
)

depth_summary["win_rate"] = (
    depth_summary["wins"]
    / depth_summary["trades"]
    * 100
)
# ============================================
# V1 20-30% DEPTH MONTHLY CONSISTENCY
# ============================================

depth_20_30 = v1_completed[
    (v1_completed["retest_depth"] > 20) &
    (v1_completed["retest_depth"] <= 30)
].copy()

depth_20_30["month"] = (
    depth_20_30["entry_time"]
    .dt.tz_localize(None)
    .dt.to_period("M")
)

depth_monthly = (
    depth_20_30
    .groupby("month")
    .agg(
        trades=("r_result", "count"),
        wins=("result", lambda x: (x == "WIN").sum()),
        losses=("result", lambda x: (x == "LOSS").sum()),
        total_r=("r_result", "sum"),
        average_r=("r_result", "mean")
    )
)

depth_monthly["win_rate"] = (
    depth_monthly["wins"]
    / depth_monthly["trades"]
    * 100
)
# ============================================
# V1 RETEST DEPTH 5% BANDS
# ============================================

v1_depth_5 = v1_completed.copy()

v1_depth_5["depth_band_5"] = pd.cut(
    v1_depth_5["retest_depth"],
    bins=list(range(0, 105, 5)),
    include_lowest=True
)

depth_5_summary = (
    v1_depth_5
    .groupby(
        "depth_band_5",
        observed=True
    )
    .agg(
        trades=("r_result", "count"),
        wins=("result", lambda x: (x == "WIN").sum()),
        losses=("result", lambda x: (x == "LOSS").sum()),
        total_r=("r_result", "sum"),
        average_r=("r_result", "mean")
    )
)

depth_5_summary["win_rate"] = (
    depth_5_summary["wins"]
    / depth_5_summary["trades"]
    * 100
)
# ============================================
# V1 20-25% DEPTH MONTHLY CONSISTENCY
# ============================================

depth_20_25 = v1_completed[
    (v1_completed["retest_depth"] > 20) &
    (v1_completed["retest_depth"] <= 25)
].copy()

depth_20_25["month"] = (
    depth_20_25["entry_time"]
    .dt.tz_localize(None)
    .dt.to_period("M")
)

depth_20_25_monthly = (
    depth_20_25
    .groupby("month")
    .agg(
        trades=("r_result", "count"),
        wins=("result", lambda x: (x == "WIN").sum()),
        losses=("result", lambda x: (x == "LOSS").sum()),
        total_r=("r_result", "sum"),
        average_r=("r_result", "mean")
    )
)

depth_20_25_monthly["win_rate"] = (
    depth_20_25_monthly["wins"]
    / depth_20_25_monthly["trades"]
    * 100
)
# ============================================
# CANDIDATE V2 - INDEPENDENT DEPTH TEST
# ============================================

# Start from ALL completed raw strategy trades,
# NOT from the filtered V1 trades.
v2_candidate = combined_df[
    combined_df["result"].isin(["WIN", "LOSS"])
].copy()

# Candidate V2 hypothesis:
# only accept retests that penetrate
# more than 20% and no more than 25%
v2_candidate = v2_candidate[
    (v2_candidate["retest_depth"] > 20) &
    (v2_candidate["retest_depth"] <= 25)
].copy()
# ============================================
# ATTACH 15M ATR REGIME TO V2 TRADES
# ============================================

v2_candidate["entry_15m"] = (
    pd.to_datetime(v2_candidate["entry_time"])
    .dt.floor("15min")
)

atr_lookup = (
    df_15m[
        [
            "atr_14_known",
            "atr_median_500",
            "atr_ratio"
        ]
    ]
    .copy()
)

v2_candidate = v2_candidate.merge(
    atr_lookup,
    left_on="entry_15m",
    right_index=True,
    how="left"
)
# ============================================
# V2 ATR REGIME ANALYSIS
# ============================================

v2_candidate["atr_regime"] = pd.cut(
    v2_candidate["atr_ratio"],
    bins=[
        -float("inf"),
        0.8,
        1.0,
        1.2,
        float("inf")
    ],
    labels=[
        "LOW",
        "BELOW_NORMAL",
        "ABOVE_NORMAL",
        "HIGH"
    ]
)

atr_regime_summary = (
    v2_candidate
    .dropna(subset=["atr_regime"])
    .groupby("atr_regime", observed=True)
    .agg(
        trades=("r_result", "count"),
        wins=("r_result", lambda x: (x > 0).sum()),
        losses=("r_result", lambda x: (x < 0).sum()),
        total_r=("r_result", "sum"),
        average_r=("r_result", "mean"),
        win_rate=("r_result", lambda x: (x > 0).mean() * 100),
        average_atr_ratio=("atr_ratio", "mean")
    )
)

print()
print("========== V2 ATR REGIME ANALYSIS ==========")
print(atr_regime_summary.round(2).to_string())
print("============================================")
v2_trades = len(v2_candidate)

v2_wins = (
    v2_candidate["result"] == "WIN"
).sum()

v2_losses = (
    v2_candidate["result"] == "LOSS"
).sum()

v2_win_rate = (
    (v2_wins / v2_trades) * 100
    if v2_trades > 0
    else 0
)

v2_total_r = v2_candidate["r_result"].sum()

v2_average_r = (
    v2_candidate["r_result"].mean()
    if v2_trades > 0
    else 0
)

v2_gross_wins = v2_candidate.loc[
    v2_candidate["r_result"] > 0,
    "r_result"
].sum()

v2_gross_losses = abs(
    v2_candidate.loc[
        v2_candidate["r_result"] < 0,
        "r_result"
    ].sum()
)

v2_profit_factor = (
    v2_gross_wins / v2_gross_losses
    if v2_gross_losses > 0
    else float("inf")
)

# Sort chronologically before drawdown calculation
v2_candidate = v2_candidate.sort_values(
    "entry_time"
).copy()

v2_candidate["cumulative_r"] = (
    v2_candidate["r_result"].cumsum()
)

v2_candidate["running_peak"] = (
    v2_candidate["cumulative_r"].cummax()
)

v2_candidate["drawdown_r"] = (
    v2_candidate["cumulative_r"]
    - v2_candidate["running_peak"]
)

v2_max_drawdown = (
    v2_candidate["drawdown_r"].min()
    if v2_trades > 0
    else 0
)

print()
print("========== CANDIDATE V2 - RAW 20-25% DEPTH ==========")
print("Trades:", v2_trades)
print("Wins:", v2_wins)
print("Losses:", v2_losses)
print("Win rate:", round(v2_win_rate, 2), "%")
print("Total R:", round(v2_total_r, 2))
print("Average R:", round(v2_average_r, 3))
print("Profit factor:", round(v2_profit_factor, 2))
print("Max drawdown:", round(v2_max_drawdown, 2), "R")
print("=====================================================")
print()
# ============================================
# # ============================================
# ============================================
# DEGRADED DATA AUDIT - 2024-09-18
# ============================================
# ============================================
# TOPSTEP COST ANALYSIS - NQ AND MNQ
# ============================================

tick_size = 0.25

contract_specs = {
    "MNQ": {
        "point_value": 2.0,
        "round_turn_fee": 1.22
    },
    "NQ": {
        "point_value": 20.0,
        "round_turn_fee": 3.78
    }
}

slippage_scenarios = [0, 1, 2, 4]

print()
print("========== TOPSTEP COST ANALYSIS ==========")

for contract_name, specs in contract_specs.items():

    point_value = specs["point_value"]
    round_turn_fee = specs["round_turn_fee"]

    print()
    print("-----", contract_name, "-----")

    for slippage_ticks in slippage_scenarios:

        cost_adjusted_results = []

        for _, trade in v2_candidate.iterrows():

            risk_points = trade["risk_points"]
            gross_r = trade["r_result"]

            if risk_points <= 0:
                continue

            risk_dollars = risk_points * point_value

            slippage_points = slippage_ticks * tick_size
            slippage_dollars = slippage_points * point_value

            total_trade_cost = (
                round_turn_fee
                + slippage_dollars
            )

            cost_in_r = total_trade_cost / risk_dollars

            net_r = gross_r - cost_in_r

            cost_adjusted_results.append(net_r)

        cost_series = pd.Series(cost_adjusted_results)

        net_total_r = cost_series.sum()
        net_average_r = cost_series.mean()

        net_wins = cost_series[cost_series > 0].sum()
        net_losses = abs(cost_series[cost_series < 0].sum())

        net_profit_factor = (
            net_wins / net_losses
            if net_losses > 0
            else float("inf")
        )

        print(
            slippage_ticks,
            "ticks slippage |",
            "Net R:",
            round(net_total_r, 2),
            "| Avg R:",
            round(net_average_r, 3),
            "| PF:",
            round(net_profit_factor, 2)
        )

print("===========================================")
# ============================================
# CANDIDATE V3 - V2 + LOW ATR
# ============================================

v3_candidate = v2_candidate[
    v2_candidate["atr_ratio"] < 0.80
].copy()

v3_trades = len(v3_candidate)
v3_wins = (v3_candidate["r_result"] > 0).sum()
v3_losses = (v3_candidate["r_result"] < 0).sum()
v3_total_r = v3_candidate["r_result"].sum()
v3_average_r = v3_candidate["r_result"].mean()

print()
print("========== CANDIDATE V3 - LOW ATR < 0.80 ==========")
print("Trades:", v3_trades)
print("Wins:", v3_wins)
print("Losses:", v3_losses)
print("Gross R:", round(v3_total_r, 2))
print("Average R:", round(v3_average_r, 3))
print("===================================================")

print()
print("========== V3 TOPSTEP COST ANALYSIS ==========")

for contract_name, specs in contract_specs.items():

    point_value = specs["point_value"]
    round_turn_fee = specs["round_turn_fee"]

    print()
    print("-----", contract_name, "-----")

    for slippage_ticks in slippage_scenarios:

        cost_adjusted_results = []

        for _, trade in v3_candidate.iterrows():

            risk_points = trade["risk_points"]
            gross_r = trade["r_result"]

            if risk_points <= 0:
                continue

            risk_dollars = risk_points * point_value

            slippage_points = slippage_ticks * tick_size
            slippage_dollars = slippage_points * point_value

            total_trade_cost = (
                round_turn_fee
                + slippage_dollars
            )

            cost_in_r = total_trade_cost / risk_dollars
            net_r = gross_r - cost_in_r

            cost_adjusted_results.append(net_r)

        cost_series = pd.Series(cost_adjusted_results)

        net_total_r = cost_series.sum()
        net_average_r = cost_series.mean()

        net_wins = cost_series[cost_series > 0].sum()
        net_losses = abs(
            cost_series[cost_series < 0].sum()
        )

        net_profit_factor = (
            net_wins / net_losses
            if net_losses > 0
            else float("inf")
        )

        print(
            slippage_ticks,
            "ticks slippage |",
            "Net R:",
            round(net_total_r, 2),
            "| Avg R:",
            round(net_average_r, 3),
            "| PF:",
            round(net_profit_factor, 2)
        )

print("=============================================")
# ============================================
# V3 MONTHLY PERFORMANCE
# ============================================

v3_candidate["month"] = (
    pd.to_datetime(v3_candidate["entry_time"])
    .dt.to_period("M")
)

v3_monthly = (
    v3_candidate
    .groupby("month")
    .agg(
        trades=("r_result", "count"),
        wins=("r_result", lambda x: (x > 0).sum()),
        losses=("r_result", lambda x: (x < 0).sum()),
        total_r=("r_result", "sum"),
        average_r=("r_result", "mean"),
        win_rate=("r_result", lambda x: (x > 0).mean() * 100)
    )
)

print()
print("========== V3 MONTHLY PERFORMANCE ==========")
print(v3_monthly.round(2).to_string())
print("============================================")
# ============================================
# V3 DRAWDOWN + STREAK ANALYSIS
# ============================================

v3_candidate["cumulative_r"] = (
    v3_candidate["r_result"].cumsum()
)

v3_candidate["running_peak"] = (
    v3_candidate["cumulative_r"].cummax()
)

v3_candidate["drawdown_r"] = (
    v3_candidate["cumulative_r"]
    - v3_candidate["running_peak"]
)

v3_max_drawdown = v3_candidate["drawdown_r"].min()

longest_loss_streak = 0
current_loss_streak = 0

for r in v3_candidate["r_result"]:

    if r < 0:
        current_loss_streak += 1
        longest_loss_streak = max(
            longest_loss_streak,
            current_loss_streak
        )
    else:
        current_loss_streak = 0

print()
print("========== V3 RISK PROFILE ==========")
print("Max drawdown:", round(v3_max_drawdown, 2), "R")
print("Longest losing streak:", longest_loss_streak)
print("=====================================")
degraded_date = "2024-09-18"

degraded_trades = v2_candidate[
    v2_candidate["entry_time"]
    .astype(str)
    .str.startswith(degraded_date)
].copy()

print()
print("========== DEGRADED DATA AUDIT ==========")
print("Date:", degraded_date)
print("V2 trades on degraded date:", len(degraded_trades))

if len(degraded_trades) > 0:
    print(
        degraded_trades[
            [
                "entry_time",
                "entry_price",
                "stop_price",
                "target_price",
                "result",
                "r_result"
            ]
        ].to_string(index=False)
    )

    print(
        "Total R on degraded date:",
        degraded_trades["r_result"].sum()
    )

print("=========================================")
print()
print("========== V1 20-25 DEPTH MONTHLY ==========")
print(depth_20_25_monthly.round(2).to_string())
print("============================================")
print()
print("========== V1 RETEST DEPTH 5% BANDS ==========")
print(depth_5_summary.round(2).to_string())
print("==============================================")
print()
print("========== V1 20-30 DEPTH MONTHLY ==========")
print(depth_monthly.round(2).to_string())
print("============================================")
print()
print("========== V1 RETEST DEPTH BANDS ==========")
print(depth_summary.round(2).to_string())
print("===========================================")
print()
print("========== V1 WINNER VS LOSER FEATURES ==========")
print(feature_comparison.round(2).to_string())
print("=================================================")
print()
print("========== V1 NEW YORK 30-MINUTE ANALYSIS ==========")
print(time_30m_summary.round(2).to_string())
print("====================================================")
print()
print("========== V1 NEW YORK SESSION ANALYSIS ==========")
print(session_summary.round(2).to_string())
print("==================================================")
print()
print("========== V1 TIME OF DAY ==========")
print(v1_time_summary.round(2).to_string())
print("====================================")
print()
print("========== V1 LOCAL TREND ANALYSIS ==========")
print(local_trend_summary.round(2).to_string())
print("=============================================")
print("=========================================")
print("=============================================")
print()
print("========== V1 MONTHLY PERFORMANCE ==========")
print(monthly_summary.round(2).to_string())
print("============================================")